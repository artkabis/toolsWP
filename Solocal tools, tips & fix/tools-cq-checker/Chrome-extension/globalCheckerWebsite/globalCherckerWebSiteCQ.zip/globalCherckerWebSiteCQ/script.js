notJquery = typeof jQuery == "undefined";
function addJquery() {
  console.log("jQuery n'est pas installé, lancement de cette librairie ...");
  //Script permettant de charger jQuery est de l'utiliser ensuite dans votre projet.
  const loadScript = async (url) => {
    const response = await fetch(url);
    const script = await response.text();
    console.log(script);
    eval(script);
  };
  const scriptUrl =
    "//cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js";
  loadScript(scriptUrl);
}
notJquery && addJquery();

function init() {
  (($) => {
    console.clear();
    console.log(
      "%cSolocal %c - checker tools %cby Greg ;)",
      "color:#0097ff;font-family:system-ui;font-size:4rem;-webkit-text-stroke: 1px black;font-weight:bold",
      "color:#0097ff;font-family:system-ui;font-size:2rem;-webkit-text-stroke: 1px black;font-weight:bold",
      "color:#0097ff;font-family:system-ui;font-size:1rem;-webkit-text-stroke: 0.2px black;font-weight:bold"
    );
    const url = window.location.href;
    const device =
      "mobile"; /*prompt('Veuillez indiquer le device à tester (mobile ou desktop) : '); */
    const apiCall = `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${url}&strategy=${device}&category=pwa&category=seo&category=performance&category=accessibility`;
    fetch(apiCall)
      .then((response) => response.json())
      .then((json) => {
        const lighthouse = json.lighthouseResult;
        const isStackPack = lighthouse?.stackPacks;
        const stack = isStackPack
          ? lighthouse?.stackPacks[0]?.title
          : undefined;
        console.log(lighthouse);
        const lighthouseMetrics = {
          "Testing device": device,
          stack,
          "First Contentful Paint":
            lighthouse?.audits["first-contentful-paint"]?.displayValue,
          "largest-contentful-paint":
            lighthouse?.audits["largest-contentful-paint"]?.displayValue,
          "Speed Index": lighthouse?.audits["speed-index"]?.displayValue,
          "Time To Interactive":
            lighthouse?.audits["interactive"]?.displayValue,
          "Performance score": lighthouse?.categories["performance"]?.score,
          "Image alt ko": lighthouse?.audits["image-alt"]?.details?.items,
        };
        console.log(
          Object.fromEntries(
            Object.entries(lighthouseMetrics).filter(([key, value]) => value)
          )
        );
      });
    const title = $('meta[property="og:title"]').attr("content");
    const desc = $('meta[name="description"]').attr("content");
    console.log(
      "----------------------------- Check META --------------------------------------------"
    );
    title && title.length > 0
      ? console.log(
          `%c Meta title : ${title} -> caractère : ${title.length} ----- (de 50 à 65)`,
          `color:${title.length >= 50 && title.length <= 65 ? "green" : "red"}`
        )
      : console.log(`%c Meta title non présent !!!`, `color:red`);
    desc && desc.length > 0
      ? console.log(
          `%c Meta description : ${desc} -> caractère : ${desc.length} ----- (de 140 à 156)`,
          `color:${desc.length >= 140 && desc.length <= 156 ? "green" : "red"}`
        )
      : console.log(`%c Meta desc non présente !!!`, `color:red`);
    console.log(
      "----------------------------- END Check META --------------------------------------------"
    );
    console.log(
      "----------------------------- Check ALT images --------------------------------------------"
    );
    $("img, svg").each(function (i, t) {
      const src = $(this).attr("src")
        ? $(this).attr("src")
        : $(this).attr("data-src");
      if (
        src &&
        this.tagName !== "svg" &&
        !src.includes("mappy") &&
        !src.includes("cdn.manager.solocal.com")
      ) {
        const alt = $(this).attr("alt");
        $(this).attr("data-src") &&
          $(this).attr("src", $(this).attr("data-src"));
        !alt &&
          alt === "" &&
          console.log(`%cNO ALT >>> ${this.src}`, "color:red");
      } else if (
        this.tagName == "svg" &&
        this.getAttribute("alt") &&
        this.getAttribute("alt").length < 1
      ) {
        console.log(
          `%cNO ALT SVG >>> ${this.getAttribute("data-icon-name")}`,
          "color:red"
        );
        console.log(this);
      }
    });
    console.log(
      "----------------------------- END Check ALT images --------------------------------------------"
    );
    console.log(
      "----------------------------- Check Hn Validity --------------------------------------------"
    );
    document.querySelectorAll("h1,h2,h3,h4,h5,h6").forEach((t, i) => {
      const nbLetters = t.textContent.length;
      const tagName = t.tagName;
      const tagContent = t.textContent
        .replaceAll("\n", " ")
        .replace(",", " ")
        .replace("’", " ")
        .replace("'", " ");
      let words = tagContent.split(" ");
      words = words.filter((w) => w.length > 3);
      //console.log('nb words : ',words.length,' mots comptabilisés : ',words.join(','))
      console.log({
        [tagName]: tagContent,
        " nb lettres": nbLetters,
        "nombre de mots comptabilisés (de 5 à 8) ": Number(words.length),
        "mots comptabilisés": words.join(",").replaceAll("\n", " "),
        node: t,
        index: i,
      });
      if (
        ((tagName === "H1" || tagName === "H2") && nbLetters < 50) ||
        nbLetters > 65
      ) {
        console.log(
          "%c" +
            tagName +
            " : " +
            tagContent +
            " ------ Erreur -> nombre de caractères : " +
            nbLetters +
            ", ne rentre pas dans la préco de 50 -> 65 caractères",
          "color:red"
        );
      }
    });
    console.log(
      "----------------------------- END Check Hn Validity --------------------------------------------"
    );

    const strongOrBold = document.querySelectorAll(
      "#Content b, #Content strong, #dm_content b, #dm_content strong"
    );
    strongOrBold &&
      console.log(
        "----------------------------- Start Check strong & bold valitidy --------------------------------------------"
      );
    let cmpBold = 0,
      boldArray = [];
    strongOrBold.forEach(function (t, i) {
      cmpBold++;
      boldArray.push({target:t, test:t.innerText});
    });
    cmpBold > 0 && console.log(boldArray);
    (cmpBold < 3 || cmpBold > 5) &&
      console.log(
        "%c Attention le nombre déléments mis en gras ne respect pas le standard (3 à 5 expressions), ici >>> " +
          cmpBold,
        "color:red"
      );
    cmpBold > 0 &&
      console.log(
        "----------------------------- End Check strong & bold valitidy --------------------------------------------"
      );
    const formatBytes = (bytes) => {
      return bytes < 1024
        ? bytes + " Bytes"
        : bytes < 1048576
        ? (bytes / 1024).toFixed(2) + " KB"
        : bytes < 1073741824
        ? (bytes / 1048576).toFixed(2) + " MB"
        : (bytes / 1073741824).toFixed(2) + " GB";
    };
    let urlsDuplicate = [],
      requestInitiatedCount = 0,
      requestCompletedCount = 0,
      imagesForAnalyseImg = [],
      imagesForAnalyseBG = [];
    const checkUrlImg = async (args) => {
      requestInitiatedCount++;
      try {
        const response = await fetch(args[1], {
          method: "GET",
        });

        const fsize = response.headers.get("content-length");
        if (fsize != null) {
          const result = {
            target: args[0],
            url: new URL(args[1]).href,
            size: formatBytes(fsize),
            alt: args[2],
            title: args[3],
            type: args[4],
            Imgwidth: args[5],
            Imgheight: args[6],
            parentwidth: args[7],
            parentheight: args[8],
            ratioWidth: args[5] / args[7],
            ratioHeight: args[6] / args[8],
            ratio: Number(
              ((args[5] / args[7] + args[6] / args[8]) / 2).toFixed(2)
            ),
          };
          console.log(result, "");
          /*317435 Bytes = 310 KB*/
          if (fsize > 317435) {
            console.log(
              "%c Warning File size exceeds 310 KB : " + result.url,
              "color: red"
            );
          }
          if (
            (result.type === "srcImage" && result.alt === null) ||
            result.alt === ""
          ) {
            console.log(
              "%c Warning SRC ALT not working : " + result.url,
              "color: red"
            );
          }
          (result.target.parents('.owl-item.cloned').length === 0 &&  result.target.parents('#logo').length !== 1) && urlsDuplicate.push({url:result.url,target:result.target});
          requestCompletedCount++;
        }
      } catch (error) {
        console.log("%cNot available", "color:yellow");
        console.log(result.target);
      }
      requestInitiatedCount === requestCompletedCount &&
        (console.log(" Fin du traitement du check des images size and alt"),
        checkUrlImgDuplicate());
    };

    const trierUrlsRepetees = (items) => {
      const occurences = {};
      items.forEach((item) => {
        const isValidUrl =
          item.url.includes("/uploads/") || item.url.includes("le-de.cdn-website");
        if (isValidUrl) {
          occurences[item.url] = occurences[item.url] ? occurences[item.url] + 1 : 1;
          occurences[item.target] = occurences[item.target] || 0;
        }
      });
      const urlsRepetees = Object.keys(occurences)
        .filter((key) => occurences[key] > 1)
        .map((key) => ({ url: key, target: items.find(item => item.url === key)?.target, iteration: occurences[key] }));
    
      return urlsRepetees;
    };
    
    const checkUrlImgDuplicate = () => {
      if (trierUrlsRepetees(urlsDuplicate).length) {
        console.log("----------------------------- Start Check duplicate images --------------------------------------------");
        console.log("%cAttention vous avez des images dupliquées sur cette page", "color:orange");
        console.log(trierUrlsRepetees(urlsDuplicate));
        console.log("----------------------------- End Check duplicate images --------------------------------------------");
      }
    };

    const checkerImageWP = () => {
      console.log(
        "----------------------------- Check validity global image --------------------------------------------"
      );

      $("img").each(function (i, t) {
        const checkMapyMarker = $(this).attr("class")
          ? !$(this).attr("class").includes("leaflet-marker-icon")
          : true;
        $(this) &&
          $(this).attr("src") &&
          !$(this).attr("src").includes("mappy") &&
          checkMapyMarker &&
          !$(this).attr("src").includes("cdn.manager.solocal.com") &&
          imagesForAnalyseImg.push({
            key: "src-img-" + i,
            value: [
              $(this),
              $(this)[0].src,
              $(this)[0].getAttribute("alt"),
              $(this)[0].getAttribute("title"),
              "srcImage",
              $(this)[0].naturalWidth,
              $(this)[0].naturalHeight,
              $(this)[0].parentNode.offsetWidth,
              $(this)[0].parentNode.offsetHeight,
            ],
          });
      });

      let cmpBgImg = 0;
      $("html *").each(function (i, t) {
        if (
          $(this).css("background-image") &&
          String($(this).css("background-image")) !== "none" &&
          String($(this).css("background-image")).includes("url(")
        ) {
          let bgimg = String($(this).css("background-image"))
            .split('url("')[1]
            .split('")')[0];
          let _this = $(this);
          let customImg = new Image();
          bgimg =
            bgimg.includes("http") || bgimg.includes("data:image/")
              ? bgimg
              : window.location.origin + bgimg;
          const detectAnotherOrigin =
            !bgimg.includes(window.location.origin) &&
            !bgimg.includes("data:image/");
          detectAnotherOrigin &&
            console.log(
              "%cImage url not current domain origin :" + bgimg,
              "color:yellow;"
            );
          bgimg =
            detectAnotherOrigin && bgimg.split("/wp-content/")[1]
              ? window.location.origin +
                "/wp-content/" +
                bgimg.split("/wp-content/")[1]
              : bgimg;
          customImg.src = bgimg;

          if (bgimg && !bgimg.includes("undefined")) {
            if (
              !bgimg.includes("mappy") &&
              !bgimg.includes("cdn.manager.solocal.com")
            ) {
              cmpBgImg++;
              !bgimg.includes("data:image/")
                ? imagesForAnalyseBG.push({
                    key: `bgimg-${cmpBgImg}`,
                    value: [
                      $(this),
                      bgimg,
                      "no alt -> gbimg",
                      "no title -> gbimg",
                      "bgImage",
                      customImg.naturalWidth,
                      customImg.naturalHeight,
                      _this[0].parentNode.offsetWidth,
                      _this[0].parentNode.offsetHeight,
                    ],
                  })
                : console.log(
                    "base64 img detected : ",
                    bgimg.includes("data:image/"),
                    " width : ",
                    customImg.width,
                    " height : ",
                    customImg.height,
                    " url : ",
                    bgimg
                  );
            }
          }
        }
      });
      const allImg = [...imagesForAnalyseBG, ...imagesForAnalyseImg];
      for (const item of allImg) {
        const content = item.value;
        checkUrlImg(content);
      }
    };

    console.log(
      "--------------------- Start check validity links -----------------------------"
    );
    let timeout = 30000;
    function check(_url, _txt, _node) {
      const response = {
        status: null,
        document: null,
      };
      return new Promise(function (resolve, reject) {
        var XMLHttpTimeout = null;
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function (data) {
          if (xhr.readyState == 4) {
            clearTimeout(XMLHttpTimeout);
            if (200 <= xhr.status && xhr.status < 400) {
              response.document = xhr.responseText;
            }
            response.source = "xhr";
            if (xhr.responseURL == _url.split("#")[0]) {
              response.status = xhr.status;
            } else {
              response.status = xhr.status;
            }
            resolve(response);
            response.status !== 404
              ? console.log(
                  `url : ${_url} %c${_txt} ->  %cstatus : %c${response.status}`,
                  "color:cornflowerblue;",
                  "color:white;",
                  "color:green"
                )
              : (console.log(
                  `url : ${_url} %c${_txt} -> %cstatus : %c${response.status}`,
                  "color:cornflowerblue;",
                  "color:white;",
                  "color:red"
                ),
                console.log("node : ", _node));
          }
        };
        try {
          xhr.open("GET", _url, true);
          xhr.onerror = function () {
            response.status = 0;
            resolve(response);
          };
          xhr.send();
        } catch (e) {
          //console.log(e);
          response.status = 0;
          resolve(response);
        }
        XMLHttpTimeout = setTimeout(function () {
          response.status = 408;
          resolve(response);
          xhr.abort();
        }, (timeout += 1000));
      });
    }
    let linksAnalyse = [];
    const linksStack = document.querySelector("#Content")
      ? document.querySelectorAll("#Content a")
      : document.querySelectorAll("#dm_content a");
    linksStack.forEach(function (t, i) {
      let url = t.getAttribute("href");

      if (url) {
        url =
          url.at(0) === "/" || url.at(0) === "?"
            ? window.location.origin + url
            : url;
        let prepubRefonteWPCheck =
          url.includes("site-privilege.pagesjaunes") ||
          url.includes("solocaldudaadmin.eu-responsivesiteeditor")
            ? true
            : !url.includes("pagesjaunes");
        const verif =
          !url.includes("tel:") &&
          !url.includes("mailto:") &&
          !url.includes("javascript:") &&
          !url.includes("logflare") &&
          !url.includes("solocal.com") &&
          !url.includes("sp.report-uri") &&
          !url.includes("chrome-extension") &&
          !url.includes("mappy") &&
          !url.includes("bloctel.gouv.fr") &&
          !url.includes("client.adhslx.com") &&
          prepubRefonteWPCheck &&
          url.at(0) !== "#";
        const txtContent =
          url &&
          url.at(-4) &&
          !url.at(-4).includes(".") &&
          t.textContent.length > 1
            ? ",  text : " + t.innerText.replace(/(\r\n|\n|\r)/gm, "")
            : "";
        verif &&
          url.includes(window.location.origin) &&
          check(url, txtContent, t);
        verif &&
          !url.includes(window.location.origin) &&
          (console.log(
            `%c Vérifier manuellement ce lien ${(url, txtContent)}`,
            "color:red"
          ),
          console.log(t),
          linksAnalyse.push(url));
      }
    });
    (($) => {
      let linksAnalys = [],
        linksCounts = {};
      $("#Content a").each(function (i, t) {
        href = $(this).attr("href");
        href &&
          href.length > 1 &&
          !href.includes("bloctel.gouv.fr") &&
          !href.includes("client.adhslx.com") &&
          href.at(0) !== "#" &&
          linksAnalys.push(href);
      });

      linksAnalys.forEach((element) => {
        linksCounts[element] = (linksCounts[element] || 0) + 1;
      });

      const entries = Object.entries(linksCounts);
      const sortedEntries = entries.sort((a, b) => a[1] - b[1]);
      sortedEntries.forEach(([link, count]) => {
        if (count > 1) {
          console.log(
            `%c Attention, vous avez des liens dupliqués sur la page : `,
            "color: orange"
          );
          console.log(
            `%cLien : ${link} - Nombre de duplications : ${count}`,
            "color: orange"
          );
        }
      });
    })(jQuery);
    setTimeout(function () {
      console.log(
        "--------------------- END check validity links -----------------------------"
      );
      $("#Wrapper").length && checkerImageWP();
    }, document.querySelectorAll("a").length * 210);
  })(jQuery);
}
!notJquery && init();
