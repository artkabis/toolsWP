

console.log('start background');

chrome.devtools.panels.create("Nom de l'onglet", "popup.html.html", "./icons/SofixedMenu-48.png", function(panel) {
  // Code exécuté lors de la création de l'onglet
  console.log('panel in devTools : ',panel);
});

chrome.action.onClicked.addListener((tab) => {
    // Vérifier si l'extension est activée sur la page web active
    console.log(tab,tab.id);
    if (tab && tab.id) {


      chrome.scripting.executeScript({
        target: {tabId: tab.id},
        files: ['./script.js'],
        // Autres options de configuration si nécessaire
      });
    }
  });

  // Example of a simple user data object
const user = {
  username: 'demo-user'
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 2. A page requested user data, respond with a copy of `user`
  if (message === 'get-user-data') {
    sendResponse(user);
  }
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'executeScript') {
    chrome.tabs.executeScript({
      code: 'window.dispatchEvent(new KeyboardEvent("keydown", {key: "J", code: "KeyJ", ctrlKey: true, shiftKey: true, metaKey: false, altKey: false, bubbles: true}));'
    });
  }
});
devtools