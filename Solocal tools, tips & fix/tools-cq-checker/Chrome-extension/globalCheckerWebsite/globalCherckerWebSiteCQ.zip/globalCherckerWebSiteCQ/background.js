

console.log('start background');


/*
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log({request},{sender},{sendResponse});
  const corsEnabled = request.corsEnabled;
  console.log({corsEnabled});
  if (corsEnabled !== undefined) {
    // Récupération de la liste des règles à ajouter depuis le dossier "rules"
    const addRules = corsEnabled ? [
      'overwrite-origin',
      'allow-credentials',
      'allow-headers',
      'referer',
      'csp',
      'allow-shared-array-buffer'
    ].map((ruleId,index) => {
      const rules = {ruleId,
        enabled: true,
        path: `rules/${ruleId}.json`};
      console.log({rules});
      return rules
      
    }) : [];

    // Mise à jour de l'état des règles
    (corsEnabled) ? chrome.declarativeNetRequest.updateDynamicRules({addRules: addRules}) : chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds: [1, 2, 3, 4, 5, 6]})
  }
});
*/

const core = {};

// const toggle = (name, rule, value, corsEnabled) => {
//   console.log('toggle arguments : ',{name}, {rule}, {value}, {corsEnabled})
//   chrome.storage.sync.get({
//     'enabled': false,
//     [name]: value
//   }, corsEnabled => {
//     console.log('rules updated:', {rule});
//     chrome.declarativeNetRequest.updateEnabledRulesets(corsEnabled ? {
//       enableRulesetIds: [rule]
//     } : {
//       disableRulesetIds: [rule]
//     });
//   });
// };
self.DEFAULT_METHODS = ['GET', 'PUT', 'POST', 'DELETE', 'HEAD', 'OPTIONS', 'PATCH', 'PROPFIND', 'PROPPATCH', 'MKCOL', 'COPY', 'MOVE', 'LOCK'];
self.DEFAULT_STATUS_METHODS = ['GET', 'POST', 'PUT', 'OPTIONS', 'PATCH', 'PROPFIND', 'PROPPATCH'];
let prefs, corsEnabled;

const toggle = (name, rule, value) => {
  console.log('toggle arguments : ',{name}, {rule}, {value})
  // chrome.storage.sync.get({
  //   'name': name,
  //   'rule': rule,
  //   'value': value
  // }, result => {
  //   console.log('result . enabled :::::::::::::::::::::',result.value, '___________result : ',{result});
    console.log('rules updated:', {rule},{value},{corsEnabled});
    chrome.declarativeNetRequest.updateEnabledRulesets(corsEnabled ? {
      enableRulesetIds: [rule]
    } : {
      disableRulesetIds: [rule]
    });
  //});
};

core['csp'] = () => toggle('remove-csp', 'csp', false);
core['allow-shared-array-buffer'] = () => toggle('allow-shared-array-buffer', 'allow-shared-array-buffer', false);
core['x-frame'] = () => toggle('remove-x-frame', 'x-frame', true);
core['allow-credentials'] = () => toggle('allow-credentials', 'allow-credentials', true);
core['allow-headers'] = () => toggle('allow-headers', 'allow-headers', false);
core['referer'] = () => toggle('remove-referer', 'referer', false);


const toggleCorsEnabled = (corsEnabled) => {
  const value = corsEnabled;
  console.log('--- toggleCorsEnabled value :', value);
  const ruleNames = ['csp', 'allow-shared-array-buffer', 'x-frame', 'allow-credentials', 'allow-headers', 'referer'];
  ruleNames.forEach(ruleName => {
    const prefName = `remove-${ruleName}`;
    
    core[ruleName](prefName, ruleName, value);
    console.log({ prefName }, { ruleName }, { value });
  });
  console.log('toggle cors:', core);
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('message bg.js:', request.corsEnabled);
  if (request.corsEnabled !== undefined) {
    chrome.storage.sync.set({ corsEnabled: request.corsEnabled }, () => {
      corsEnabled = request.corsEnabled;
      toggleCorsEnabled(corsEnabled);
    });
  }
});

const once = () => {
  chrome.storage.sync.get('corsEnabled', result => {
    corsEnabled = result.corsEnabled;
    toggleCorsEnabled();
  });
};

chrome.runtime.onInstalled.addListener(once);
chrome.runtime.onStartup.addListener(once);