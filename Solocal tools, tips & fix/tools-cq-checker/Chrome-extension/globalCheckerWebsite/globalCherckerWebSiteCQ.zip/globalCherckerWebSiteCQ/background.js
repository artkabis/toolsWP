

console.log('start background');

// chrome.devtools.panels.create("Nom de l'onglet", "popup.html.html", "./icons/SofixedMenu-48.png", function(panel) {
//   // Code exécuté lors de la création de l'onglet
//   console.log('panel in devTools : ',panel);
// });

// chrome.action.onClicked.addListener((tab) => {
//     // Vérifier si l'extension est activée sur la page web active
//     console.log(tab,tab.id);
//     if (tab && tab.id) {


//       chrome.scripting.executeScript({
//         target: {tabId: tab.id},
//         files: ['./script.js'],
//         // Autres options de configuration si nécessaire
//       });
//     }
//   });

//   // Example of a simple user data object
// const user = {
//   username: 'demo-user'
// };

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   // 2. A page requested user data, respond with a copy of `user`
//   if (message === 'get-user-data') {
//     sendResponse(user);
//   }
// });

// chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
//   if (message.action === 'executeScript') {
//     chrome.tabs.executeScript({
//       code: 'window.dispatchEvent(new KeyboardEvent("keydown", {key: "J", code: "KeyJ", ctrlKey: true, shiftKey: true, metaKey: false, altKey: false, bubbles: true}));'
//     });
//   }
// });







/*
// devtools
let isEnabled = true; // Par défaut, la règle est activée
const storageKey = 'toggleState';

chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1] // Remplacez 1 par l'ID de la règle que vous souhaitez supprimer
  });
  // Récupérer l'état précédent du stockage local lors de l'installation
  chrome.storage.local.get([storageKey], (result) => {
    isEnabled = result[storageKey] || true;
    console.log({isEnabled})
  });
});

chrome.runtime.onConnect.addListener((port) => {
  console.log({port});
  if (port.name === 'popup') {
    // Envoyer un message au popup avec l'état actuel de la règle
    port.postMessage({ isEnabled: isEnabled });

    // Ajouter un écouteur d'événement pour les messages provenant du popup
    port.onMessage.addListener((message) => {
      isEnabled = message.isEnabled;

      if (isEnabled) {
        // Supprimer la règle
        chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: [1]
        });
      } else {
        // Ajouter la règle
        chrome.declarativeNetRequest.updateDynamicRules({
          addRules: [
            {
              id: 1,
              priority: 1,
              action: {
                type: 'modifyHeaders',
                responseHeaders: [
                  {
                    header: 'Access-Control-Allow-Origin',
                    operation: 'remove'
                  }
                ]
              },
              condition: {
                urlFilter: '<all_urls>',
                resourceTypes: ['main_frame', 'sub_frame']
              }
            }
          ]
        });
      }
    });
  }
});

*/
/*
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installée.');
  
  // Définition des règles de requête
  chrome.declarativeNetRequest.updateDynamicRules({ 
    removeRuleIds: [1], // Supprimer les règles existantes
    addRules: [
      {
        id: 'corsRule',
        priority: 1,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            {
              header: 'Access-Control-Allow-Origin',
              operation: 'add',
              value: '*'
            }
          ]
        },
        condition: {
          urlFilter: '<all_urls>'
        }
      }
    ]
  });
});
*/
navigator.serviceWorker.register('background.js')
  .then(() => {
    console.log('Service worker enregistré avec succès.');
  })
  .catch((error) => {
    console.error('Erreur lors de l\'enregistrement du service worker:', error);
  });
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installée.');

  // Définition des règles de requête
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1], // Supprimer la règle existante avec l'ID 1
    addRules: [
      {
        id: 1, // Réutiliser l'ID 1 pour la nouvelle règle
        priority: 1,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            {
              header: 'Access-Control-Allow-Origin',
              operation: 'set', // Utiliser 'set' au lieu de 'add'
              value: '*'
            }
          ]
        },
        condition: {
          urlFilter: '<all_urls>'
        }
      }
    ]
  });
});




// chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//   if (request.action === 'toggleCORS') {
//     chrome.storage.sync.get({ corsEnabled: true }, function(data) {
//       var newCORSState = !data.corsEnabled;

//       chrome.storage.sync.set({ corsEnabled: newCORSState }, function() {
//         // Envoyer une réponse facultative au popup.js (optionnel)
//         sendResponse({ corsEnabled: newCORSState });
//       });
//     });
//   }

//   // Indiquez que la réponse sera envoyée de manière asynchrone
//   return true;
// });



/*
const v2 = {};

v2.headersReceived = d => {
  const { responseHeaders } = d;
  for (const o of v2.headersReceived.methods) {
    o.method(d);
    if (o.once) {
      v2.headersReceived.methods.delete(o);
    }
  }

  return {
    responseHeaders
  };
};
v2.headersReceived.methods = new Set();

v2.beforeSendHeaders = d => {
  const { requestHeaders } = d;
  for (const o of v2.beforeSendHeaders.methods) {
    o.method(d);
    if (o.once) {
      v2.beforeSendHeaders.methods.delete(o);
    }
  }

  return { requestHeaders };
};
v2.beforeSendHeaders.methods = new Set();

v2.install = prefs => {
  v2.prefs = prefs;
  chrome.webRequest.onHeadersReceived.removeListener(v2.headersReceived);
  chrome.webRequest.onHeadersReceived.addListener(
    v2.headersReceived,
    { urls: ['<all_urls>'] },
    ['blocking', 'responseHeaders', 'extraHeaders']
  );

  chrome.webRequest.onBeforeSendHeaders.removeListener(v2.beforeSendHeaders);

  const m = ['requestHeaders'];
  if (v2.prefs['fix-origin']) {
    m.push('blocking', 'extraHeaders');
  }
  chrome.webRequest.onBeforeSendHeaders.addListener(
    v2.beforeSendHeaders,
    { urls: ['<all_urls>'] },
    m
  );
};

v2.remove = () => {
  chrome.webRequest.onHeadersReceived.removeListener(v2.headersReceived);
  chrome.webRequest.onBeforeSendHeaders.removeListener(v2.beforeSendHeaders);
};

// Access-Control-Allow-Headers for OPTIONS
v2.beforeSendHeaders.methods.add({
  method: d => {
    if (d.method === 'OPTIONS') {
      const r = d.requestHeaders.find(
        ({ name }) => name.toLowerCase() === 'access-control-request-headers'
      );

      if (r) {
        const { requestId } = d;

        v2.headersReceived.methods.add({
          method: d => {
            if (d.method === 'OPTIONS' && d.requestId === requestId) {
              d.responseHeaders.push({
                name: 'Access-Control-Allow-Headers',
                value: r.value
              });
            }
          },
          once: true
        });
      }
    }
  }
});

// Access-Control-Allow-Origin
{
  const redirects = {};
  chrome.tabs.onRemoved.addListener(tabId => delete redirects[tabId]);

  v2.headersReceived.methods.add({
    method: d => {
      if (v2.prefs['overwrite-origin'] && d.type !== 'main_frame') {
        const { initiator, originUrl, responseHeaders } = d;
        let origin = '*';

        if (v2.prefs['unblock-initiator'] || v2.prefs['allow-credentials']) {
          if (!redirects[d.tabId] || !redirects[d.tabId][d.requestId]) {
            try {
              const o = new URL(initiator || originUrl);
              origin = o.origin;
            } catch (e) {}
          }
        }
        if (d.statusCode === 301 || d.statusCode === 302) {
          redirects[d.tabId] = redirects[d.tabId] || {};
          redirects[d.tabId][d.requestId] = true;
        }

        const r = responseHeaders.find(
          ({ name }) => name.toLowerCase() === 'access-control-allow-origin'
        );

        if (r) {
          if (r.value !== '*') {
            r.value = origin;
          }
        } else {
          responseHeaders.push({
            name: 'Access-Control-Allow-Origin',
            value: origin
          });
        }
      }
    }
  });
}

// Referrer and Origin
{
  v2.beforeSendHeaders.methods.add({
    method: d => {
      if (v2.prefs['fix-origin']) {
        try {
          const o = new URL(d.url);
          d.requestHeaders.push({
            name: 'referer',
            value: d.url
          }, {
            name: 'origin',
            value: o.origin
          });
        } catch (e) {}
      }
    }
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleCORS') {
    if (request.enable) {
      v2.install(request.prefs);
    } else {
      v2.remove();
    }
  }
});

*/
