document.querySelector('#analyserBtn').addEventListener('click', function(){
    alert('Lancer le scan ?');
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0];
        var tabId = activeTab.id;
        var tabUrl = activeTab.url;

        chrome.tabs.get(tabId, function(tab) {
            var tabContent = tab ? tab.content : null;
            console.log(tab,{tabContent});
            if (tab) {
                // Exécution du fichier script.js dans l'onglet actif
                chrome.scripting.executeScript({
                    target: {tabId: tab.id},
                    files: ['./jquery-3.6.4.min.js','./script.js'],
                    // Autres options de configuration si nécessaire
                }, function(results) {
                    // Résultats de l'exécution du script (si nécessaire)
                    console.log(results);
                });
            }
        });
    }); 
});