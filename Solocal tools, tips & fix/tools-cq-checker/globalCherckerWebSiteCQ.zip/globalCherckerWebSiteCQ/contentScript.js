console.log('contenScript loaded successfully')
DevToolsAPI.showPanel('console');