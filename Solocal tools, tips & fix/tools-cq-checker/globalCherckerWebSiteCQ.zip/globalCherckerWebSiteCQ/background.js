

console.log('start background');

chrome.action.onClicked.addListener((tab) => {
    // Vérifier si l'extension est activée sur la page web active
    console.log(tab,tab.id);
    if (tab && tab.id) {


      chrome.scripting.executeScript({
        target: {tabId: tab.id},
        files: ['./script.js'],
        // Autres options de configuration si nécessaire
      });
    }
  });

  // Example of a simple user data object
const user = {
  username: 'demo-user'
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 2. A page requested user data, respond with a copy of `user`
  if (message === 'get-user-data') {
    sendResponse(user);
  }
});


