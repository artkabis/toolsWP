
  function executeScriptInTab(tab, sitemap) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: mainFunction,
      args: [sitemap]
    });
  }
  function executeScriptInTabGoogle(tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: function(){
        window.open('https://search.google.com/test/rich-results?utm_source=support.google.com%2Fwebmasters%2F&utm_medium=referral&utm_campaign=7445569&url='+encodeURIComponent(window.location.href),'_blank', 'width=500,height=800,toolbar=no');
      },
    });
  }
  function executeScriptDesignModeToggle(tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: function(){
        let dn = document.designMode; 
        document.designMode = (dn==="off") ? 'on' : 'off';
      },
    });
  }
  function executeScriptDudaPages(tab) {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          function: () => {
                if(document.querySelector('#dm')){
                    const menuJson = JSON.parse(atob(document.head.innerHTML.split('NavItems: ')[1].split("\',")[0].replaceAll("'",'')));
                    const subNavOk = menuJson.filter((t)=>t.subNav.length>0);
                    const nv1OutNav = menuJson.filter((t)=>t.inNavigation===false);
                    const nv1InNav = menuJson.filter((t)=>t.inNavigation===true);
                    nv1OutNav.map((t)=>t.niveau1Out = true),nv1InNav.map((t)=>t.niveau1In = true);
                    const nv2OutNav = (subNavOk) && subNavOk.filter((s)=>s.inNavigation==false);
                    nv2OutNav.niveau2Out = true;
                    const nv2InNav = (subNavOk) && subNavOk.filter((s)=>s.inNavigation==true);
                    nv2InNav.niveau2In = true;
                    const finalNavOut = (nv2OutNav>0) ? {nv1OutNav,nv2OutNav} : nv1OutNav;
                    const finalNavIn = (nv2InNav>0) ? {nv1InNav,nv2InNav} : nv1InNav;
                    console.log('---------------------------------- Visible en navigation (depuis le menu) --------------------------------------------');
                    console.table( finalNavIn );
                    console.log('---------------------------------- Non visible dans la navigation (depuis le menu) --------------------------------------------');
                    console.table( finalNavOut );
                    finalNavOut.map((t)=>{console.log('links outer nav : ',window.location.origin+t.path) });
                }
            }          
        });
      });
    
  }
  
    // function executeScriptInTabConsole(tab) {
    //     console.log(' before executeScriptInTabConsole start',tab);
    //     chrome.scripting.executeScript({
    //         target: { tabId: tab.id },
    //         function: function(){
    //             console.log('executeScriptInTabConsole start');
    //             chrome.devtools.inspectedWindow.eval("DevToolsAPI.showPanel('console')");
    //         },
    //     });
    // }
  function mainFunction(sitemap) {
    console.log("open sitemap : ", window.location.origin + sitemap)
    window.open(window.location.origin + sitemap,'_blank', 'width=500,height=800,toolbar=no')
  }
  
  document.querySelector('[id*="sitemap"]').addEventListener('click', function() {
    const sitemap = (String(this.id).includes('sitemapWP')) ? "/page-sitemap.xml" : "/sitemap.xml";
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      executeScriptInTab(tabs[0], sitemap);
    });
  });

document.querySelector('#openGoogleSchemaValidator').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        executeScriptInTabGoogle(tabs[0]);
      });
    
});
document.querySelector('#designModeToggle').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        executeScriptDesignModeToggle(tabs[0]);
      });
    
});
document.querySelector('#linksDuda').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        executeScriptDudaPages(tabs[0]);
      });
    
});


document.querySelector('#analyserBtn').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0];
        var tabId = activeTab.id;
        var tabUrl = activeTab.url;
        chrome.tabs.get(tabId, function(tab) {
            var tabContent = tab ? tab.content : null;
            console.log(tab,{tabContent});
            if (tab) {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id},
                    files: ['./jquery-3.6.4.min.js','./script.js'],//,'./contentScript.js'],
                }, function(results) {
                    //DevToolsAPI.showPanel('console');
                    window.close();
                });
            }
        });
    }); 
});


// 1. Send a message to the service worker requesting the user's data
chrome.runtime.sendMessage('get-user-data', (response) => {
    // 3. Got an asynchronous response with the data from the service worker
    console.log('received user data from back', response);
});


