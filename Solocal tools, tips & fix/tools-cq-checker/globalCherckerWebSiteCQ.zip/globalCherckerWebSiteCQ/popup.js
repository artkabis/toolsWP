
  function executeScriptInTab(tab, sitemap) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: mainFunction,
      args: [sitemap]
    });
  }
  function executeScriptInTabGoogle(tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: function(){
        window.open('https://search.google.com/test/rich-results?utm_source=support.google.com%2Fwebmasters%2F&utm_medium=referral&utm_campaign=7445569&url='+encodeURIComponent(window.location.href),'_blank');
      },
    });
  }
    // function executeScriptInTabConsole(tab) {
    //     console.log(' before executeScriptInTabConsole start',tab);
    //     chrome.scripting.executeScript({
    //         target: { tabId: tab.id },
    //         function: function(){
    //             console.log('executeScriptInTabConsole start');
    //             chrome.devtools.inspectedWindow.eval("DevToolsAPI.showPanel('console')");
    //         },
    //     });
    // }
  function mainFunction(sitemap) {
    console.log("open sitemap : ", window.location.origin + sitemap)
    window.open(window.location.origin + sitemap)
  }
  
  document.querySelector('[id*="sitemap"]').addEventListener('click', function() {
    const sitemap = (String(this.id).includes('sitemapWP')) ? "/page-sitemap.xml" : "/sitemap.xml";
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      executeScriptInTab(tabs[0], sitemap);
    });
  });

document.querySelector('#openGoogleSchemaValidator').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        executeScriptInTabGoogle(tabs[0]);
      });
    
});
document.querySelector('#analyserBtn').addEventListener('click', function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var activeTab = tabs[0];
        var tabId = activeTab.id;
        var tabUrl = activeTab.url;
        chrome.tabs.get(tabId, function(tab) {
            var tabContent = tab ? tab.content : null;
            console.log(tab,{tabContent});
            if (tab) {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id},
                    files: ['./jquery-3.6.4.min.js','./script.js'],//,'./contentScript.js'],
                }, function(results) {
                    //DevToolsAPI.showPanel('console');
                    //window.close();
                });
            }
        });
    }); 
});